export default function WrongUrl() {

    return <>
        <div className="mt-5">
            <h1>Page Not Found</h1>
        </div>
    </>
}