export default function Register() {
    return <>
    </>
}