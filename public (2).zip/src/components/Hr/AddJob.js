import { Link } from "react-router-dom";

export default function AddJob() {
    return <>



        "title":"Ionic App",
        "discription":"Ionic App Development",
        "companyName":"Systango",
        "companyAddress":"IT Park",
        "email":"hrsys@gmail.com",
        "contact":"9623249147",
        "qualification":"MCA",
        "experience":"0",
        "skills":"HTML, CSS",
        "salary":"8000",
        "jobtype":"OnSite",
        "joblocation":"OnSite",
        "postdate":"2023-11-29",
        "expirydate":"2023-12-29"

        <section className="contact-section">
            <div className="container">
                <div className="row">
                    <div className="col-12">
                        <h2 className="contact-title">Save New Hr</h2>
                    </div>
                    <div className="col-lg-8">
                        <form className="form-contact contact_form" id="contactForm" novalidate="novalidate">
                            <div className="row">

                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Category</label>
                                        <select className="form-control form-select valid" type="text">
                                            <option>Select Category</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Job Title</label>
                                        <input className="form-control valid" name="name" id="name" type="text" placeholder="Enter Job Title" />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Job description</label>
                                        <input className="form-control valid" name="name" id="name" type="text" placeholder="Enter Job Description" />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Company Name</label>
                                        <input className="form-control valid" name="name" id="name" type="text" placeholder="Enter Company Name" />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Company Address</label>
                                        <input className="form-control valid" name="name" id="name" type="text" placeholder="Enter Company Address" />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Contact</label>
                                        <input className="form-control valid" name="phone" id="phone" type="number" placeholder="Enter Phone Number" />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Email</label>
                                        <input className="form-control valid" name="email" id="email" type="email" placeholder="Enter Username / email" />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Qualification</label>
                                        <input className="form-control valid" name="password" id="phone" type="text" placeholder="Enter Qualification" />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Experiecne</label>
                                        <input className="form-control valid" name="exp" id="phone" type="text" placeholder="Enter Experience" />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Skills</label>
                                        <input className="form-control valid" name="skills" id="phone" type="text" placeholder="Enter Required Skills" />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Job Type</label>
                                        <select className="form-control form-select valid" type="text">
                                            <option>Select Type</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Job Location</label>
                                        <input className="form-control valid" name="skills" id="phone" type="text" placeholder="Enter Location" />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Salary</label>
                                        <input className="form-control valid" name="skills" id="phone" type="number" placeholder="Enter Salary" />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <label>Expiry Date</label>
                                        <input className="form-control valid" name="skills" id="date" type="date" />
                                    </div>
                                </div>

                            </div>
                            <div className="form-group mt-3">
                                <button type="submit" className="button button-contactForm boxed-btn">Save</button>
                            </div>
                            {/* <b>{msg}</b> */}
                        </form>
                    </div>
                    <div className="col-lg-3 offset-lg-1">
                        <div className="media contact-info">
                            <span className="contact-info__icon"><i className="ti-user"></i></span>
                            <div className="media-body">
                                <h3><Link to="/hrlist">Hr Details </Link></h3>

                            </div>
                        </div>
                        <div className="media contact-info">
                            <span className="contact-info__icon"><i className="ti-user"></i></span>
                            <div className="media-body">
                                <h3><Link to="">Jobs Details</Link></h3>

                            </div>
                        </div>
                        <div className="media contact-info">
                            <span className="contact-info__icon"><i className="ti-user"></i></span>
                            <div className="media-body">
                                <h3><Link to="">Candidates Details</Link></h3>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


    </>
}