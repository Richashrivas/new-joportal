import { createSlice } from '@reduxjs/toolkit'

const slice = createSlice({

    name: "Jobdata",
    initialState: {
        value: []
    },
    reducers: {
        JobListReducer: (state, action) => {
            state.value = action.payload
        }
    }
})

export const { JobListReducer } = slice.actions
export default slice.reducer