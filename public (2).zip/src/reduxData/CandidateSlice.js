import { createSlice } from '@reduxjs/toolkit'

const slice = createSlice({

    name: "candidateData",
    initialState: {
        value: []
    },
    reducers: {
        CandidateListReducer: (state, action) => {
            state.value = action.payload
        }
    }
})

export const { CandidateListReducer } = slice.actions
export default slice.reducer